#include<stdio.h>
#include<unistd.h>

int main()
{
//	system("gzip -f /home/visionx/Desktop/wait.c");
	system("cd set/");
}
