#include<stdio.h>
int main()
{
      if(	fork()==0)
      if(	fork()==0)
      if(	fork()==0)
	printf("Hello\n");
}
