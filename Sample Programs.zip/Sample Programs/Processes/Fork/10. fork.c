#include<stdio.h>

int main()
{
	fork();
	fork();
	fork();
	printf("Sample text.\n");
}
